<?php
/**
 * Created by PhpStorm.
 * User: Etudiant
 * Date: 30/11/2018
 * Time: 14:54
 */

namespace App\Controller\Admin;


use App\Entity\Category;
use App\Form\CategoryType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class CategoryController
 * @package App\Controller\Admin
 * @Route("/categorie")
 */
class CategoryController extends AbstractController
{
    /**
     * 1° Page princile du BO qui affiche toutes nos catégories en base
     * @Route("/")
     */
    public function index()
    {
        $em = $this->getDoctrine()->getManager();

        $repository = $em->getRepository(Category::class);

        // $categories = $repository->findAll();
        // OU
        $categories = $repository->findBy([], ['name'=>'asc']); // ici meme chose qu'au dessus sauf qu'on lui applique un tri ['name'=>'asc']
        // a noter que findBy([]) avec les crochets vides est l'équivalent dans findAll()

        return $this->render(
            'admin/category/index.html.twig',
            [
                'categories' => $categories
            ]
        );
    }

    /**
     * 2° Methode qui permet de créer/modifier des catégories en back office
     * @Route("/edition")
     */
    public function edit(Request $request)
    {
        $em = $this->getDoctrine()->getManager();

        $categorie = new Category();

        // Création d'un form lié à la catégorie
        $form = $this->createForm(CategoryType::class, $categorie);

        // le formulaire analyse la requete HTTP et traitre le formulaire s'il a été soumis
        $form->handleRequest($request);

        // si le formulaire a été envoyé
        if($form->isSubmitted()){
            dump($categorie);

            // si les validations à partir des annotations dans l'entité Category sont OK
            if($form->isValid()){
                // enregistrement de la catégorie en bdd
                $em->persist($categorie);
                $em->flush();

                // message de confirmation
                $this->addFlash('success', 'La catégorie est bien enregistrée');
                // redirection vers la liste apres enregistrement
                return $this->redirectToRoute('app_admin_category_index');
            } else{
                $this->addFlash('error', 'Le formulaire contient des erreurs');
            }
        }

        return $this->render(
            'admin/category/edit.html.twig',
            [
                // passage du formulaire au template
                'form' => $form->createView()
            ]
        );
    }
}